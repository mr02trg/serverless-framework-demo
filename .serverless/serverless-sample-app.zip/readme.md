# Serverless Framework demo

Perform `sls login` to authenticate your serverless app

# Test locally
`sls invoke local -f <function-name> -d <input-event>`\
sls invoke local -f hello -d "{'key': 'value'}"

# Deploy
Deploying all resources\
`sls deploy`

Deploying specific lambda function \
`sls deploy --stage [dev|prod|staging] -f <lambda-function-name>`

# Remove
`sls remove`
