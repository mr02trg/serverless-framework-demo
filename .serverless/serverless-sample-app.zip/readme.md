# Serverless Framework demo

# Test locally
`sls invoke local -f <function-name> -d <input-event>`
sls invoke local -f hello -d "{'key': 'value'}"

# Deploy
`sls deploy`
