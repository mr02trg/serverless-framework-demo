
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'tuetruong',
  applicationName: 'serverless-demo',
  appUid: '4nY0dVfbRd7nVnXzwH',
  orgUid: '84c8a005-f45f-42aa-8320-3e36184bb1e9',
  deploymentUid: 'be196915-b39f-4681-b0ee-a620b434e3ba',
  serviceName: 'serverless-sample-app',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.0.0',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'serverless-sample-app-dev-hello', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.hello, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}